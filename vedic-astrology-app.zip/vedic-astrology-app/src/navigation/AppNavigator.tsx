import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { onAuthStateChanged, User } from 'firebase/auth';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { auth } from '@/services/firebase';
import { AboutUsScreen } from '@/screens/AboutUsScreen';
import { ContactUsScreen } from '@/screens/ContactUsScreen';
import { BookAppointmentScreen } from '@/screens/BookAppointmentScreen';
import { PaymentScreen } from '@/screens/PaymentScreen';
import { MyBookingsScreen } from '@/screens/MyBookingsScreen';
import { AdminCalendarScreen } from '@/screens/admin/AdminCalendarScreen';
import { colors } from '@/constants/theme';

export type RootStackParamList = {
  AboutUs: undefined;
  ContactUs: undefined;
  BookAppointment: undefined;
  Payment: { bookingId: string; amountPaise: number };
  MyBookings: undefined;
  AdminCalendar: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

/**
 * ADMIN GATING: isAdmin is read from the Firebase Auth custom claim
 * (idTokenResult.claims.admin), set server-side only — never something the
 * client can set on itself. This gate controls navigation/UI visibility;
 * the actual enforcement is server-side in admin.ts's requireAdmin check,
 * so even a modified client build cannot call admin functions successfully.
 */
export function AppNavigator(): React.JSX.Element {
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      if (nextUser) {
        const tokenResult = await nextUser.getIdTokenResult();
        setIsAdmin(tokenResult.claims.admin === true);
      } else {
        setIsAdmin(false);
      }
      setInitializing(false);
    });
    return unsubscribe;
  }, []);

  if (initializing) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator accessibilityLabel="Loading app" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="AboutUs">
        <Stack.Screen name="AboutUs" component={AboutUsScreen} options={{ title: 'About Us' }} />
        <Stack.Screen
          name="ContactUs"
          component={ContactUsScreen}
          options={{ title: 'Contact Us' }}
        />
        <Stack.Screen
          name="BookAppointment"
          component={BookAppointmentScreen}
          options={{ title: 'Book Appointment' }}
        />
        <Stack.Screen name="Payment" component={PaymentScreen} options={{ title: 'Payment' }} />
        {user ? (
          <Stack.Screen name="MyBookings" options={{ title: 'My Bookings' }}>
            {() => <MyBookingsScreen userId={user.uid} onReschedule={() => undefined} />}
          </Stack.Screen>
        ) : null}
        {isAdmin ? (
          <Stack.Screen
            name="AdminCalendar"
            component={AdminCalendarScreen}
            options={{ title: 'Manage Availability' }}
          />
        ) : null}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.background,
  },
});
